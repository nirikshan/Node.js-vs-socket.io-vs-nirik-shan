var app = require('express')();
var  server = require('http').Server(app);
var io = require('socket.io')(server);
var bp = require("body-parser");
var user;
var online = {};

app.use(bp.urlencoded({ extended: false }));
app.use(bp.json());

server.listen(3000);

app.get('/', function(req, res){
	res.sendfile(__dirname + '/index.html');
});





io.on('connection',function(socket) {


	socket.on('New_user',function(data,callback) {
	      if (data in online) {
		  	callback(false);
		  } else {
		  	callback(true);
		  	socket.username = data;
		  	online[socket.username] = socket;
		  	//online.push(socket.username);
		  	console.log(data + '  is connected');
            updtng_nw_usr();
		  }
	    
	});

	socket.on('disconnect',function(){
		if (socket.username) {
			delete online[socket.username];
			//online.splice(online.indexOf(socket.username),1);
			updtng_nw_usr();
			console.log(socket.username + '  is disconnected');
		}
	});

	function updtng_nw_usr(){
	  var html = " ";
	  for (var i = 0; i < Object.keys(online).length; i++) {
	    html = Object.keys(online)[i] +'<br>' + html;
	  }
	  io.sockets.emit('all_users',html);
	}

	socket.on('msg_k',function(data , callback){
        var msg = data.trim();
        var border_pos = msg.indexOf('$');
        var pure_msg = msg.substr(0,border_pos);
        var to = msg.substr(border_pos+1)
        if (pure_msg.trim() !== '') {
          if (to.trim() !== '') {
             if (to in online) { 
                online[to].emit('call','<b>'+ socket.username +' :</b>'+'<span style="color:red;">'+pure_msg+'</span>');
              }else {
                callback('User is Not In Online...');
              }
          }else{//public msg when to box is empty
            io.sockets.emit('snd_mg','<b>'+ socket.username +' :</b>'+'<span style="color:red;">'+pure_msg+'</span>');
          }
        }
	});

	

	socket.on('typing_ray',function(data){
       socket.broadcast.emit('eva','<b>'+ socket.username +' :</b>'+'<span style="color:red;">Typyng...</span>');
	});

    socket.on('stop_ray',function(data){
       socket.broadcast.emit('eva','');
	});

});


    