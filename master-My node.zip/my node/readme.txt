Install socket.io

npm install socket.io --save

Install body-parser

npm-install body-parser --save


Install Express

npm install -g express --save
          or
npm install express --save


By Nirikshan bhusal
